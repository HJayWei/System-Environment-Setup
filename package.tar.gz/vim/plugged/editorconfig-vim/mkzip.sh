#!/bin/sh

zip -r editorconfig-vim-$*.zip plugin/* autoload/* doc/*
